The file "microsatellite_conservation_data.csv" contains the data and results from Sawaya et al. "Measuring Microsatellite Conservation in Mammalian Evolution with a Phylogenetic Birth-Death Model".  The first three columns are the positions for each microsatellite in the genome build hg18.  The fourth column is the motif of the microsatellite.  

The 5th, 6th and 7th column are the posterior probabilities that each site belongs to the death rate category "low", "medium" and "high" (see text).  

The 8th and 9th column are from the Genomic Regions Enrichment of Annotations Tool (http://great.stanford.edu/), and are the name of the gene for which the microsatellite falls nearest to the canonical transcription start site and the distance to that site. 

The remaining columns represent the presence (1) or absence (0) of the microsatellite in alignments with the genomes of 11 other mammals.  The names of the genome builds used in the alignment are the header for these columns.

The file "types.csv" contains microsatellite motifs, lengths, number of mismatches, and function region positions.
